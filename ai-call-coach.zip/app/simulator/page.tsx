'use client';
import React, { useEffect, useMemo, useRef, useState } from "react";

const objections = [
  "zu teuer","kein bedarf","keine zeit","schon lieferant","kein interesse","später","budget","entscheidung","chef","daten schicken",
];
const closingSignals = [
  "klingt gut","interessant","wie geht es weiter","angebot","termin","demo","schicken","email","preis","vertrag","start",
];
const discoveryKeywords = [
  "bedarf","ziel","problem","herausforderung","prozess","status quo","volumen","entscheidung","zeitrahmen","kriterien","stakeholder",
];
const valueKeywords = [
  "nutzen","vorteil","roi","zeit sparen","kosten senken","umsatz","effizienz","qualität","risiko","sicherheit",
];

const SCENARIOS: any = {
  cold: {
    id: "cold",
    title: "Kaltakquise",
    persona: {
      name: "Herr Becker",
      role: "COO eines mittelständischen Logistikers",
      attitude: "leicht genervt, knapp angebunden",
      goals: "Zeit sparen, Störungen vermeiden, keine Experimente",
    },
    opener: "Guten Tag, hier Becker. Wer ist da? Ich habe nur kurz Zeit.",
    hints: [
      "Klare Nutzenformulierung in 15 Sekunden",
      "Frage nach Problem/Ziel statt Produkt-Pitch",
      "Mit Einwand umgehen und nächste Mikro-Zusage holen",
    ],
  },
  discovery: {
    id: "discovery",
    title: "Bedarfsanalyse",
    persona: {
      name: "Frau König",
      role: "Leiterin Kundenservice eines E-Commerce",
      attitude: "kooperativ, aber kritisch",
      goals: "First-Call-Resolution und bessere Erreichbarkeit",
    },
    opener: "Hallo, hier ist König. Womit starten wir?",
    hints: [
      "Offene Fragen zu Ist-Prozess, KPIs, Constraints",
      "Aktives Zuhören, Zusammenfassen, Next Step sichern",
      "Mindestens 3 Discovery-Fragen stellen",
    ],
  },
  closing: {
    id: "closing",
    title: "Abschluss",
    persona: {
      name: "Herr Meier",
      role: "CEO eines SaaS-Startups",
      attitude: "zahlengetrieben, knapp",
      goals: "schneller ROI, geringes Risiko",
    },
    opener: "Okay. Wir haben wenig Zeit. Was schlagen Sie konkret vor?",
    hints: [
      "Klares Angebot mit 2 Optionen",
      "Einwand behandeln, dann Commitment sichern",
      "Nächsten Termin oder Startdatum fixieren",
    ],
  },
};

function aiReply({ scenario, userMsg, turns }: any) {
  const msg = (userMsg || "").toLowerCase();
  const t = turns.length;
  if (t === 0) return SCENARIOS[scenario].opener;

  const hasObjection = objections.some((k) => msg.includes(k));
  const hasClose = closingSignals.some((k) => msg.includes(k));
  const asksDiscovery = discoveryKeywords.some((k) => msg.includes(k));
  const talksValue = valueKeywords.some((k) => msg.includes(k));

  if (scenario === "cold") {
    if (hasObjection) return "Verstehe. Was müsste denn gegeben sein, damit sich ein 10-Minuten-Termin für Sie lohnt?";
    if (asksDiscovery) return "Aktuell sind die größten Engpässe Durchlaufzeiten und Ausfallmanagement. Was wäre Ihr wichtigstes Ziel für Q4?";
    if (talksValue) return "Wenn wir 20 Prozent Zeit im Dispo sparen, wäre das interessant? Dann schlage ich einen 15-Minuten-Termin vor.";
    return "Ich habe wenig Zeit. Was ist der konkrete Nutzen in einem Satz?";
  }
  if (scenario === "discovery") {
    if (asksDiscovery) return "Wir haben aktuell 68 Prozent FCR und Wartezeiten von 2:30 Minuten. Welche KPI ist für Sie kritisch?";
    if (hasObjection) return "Alles gut. Welche Bedingungen müssten erfüllt sein, damit Sie weitergehen?";
    if (talksValue) return "Konkret: 15 Prozent FCR-Plus in 8 Wochen. Welche Risiken sehen Sie?";
    return "Können Sie Ihren aktuellen Prozess in drei Schritten skizzieren?";
  }
  if (scenario === "closing") {
    if (hasClose) return "Gut. Variante A Pilot 4 Wochen, Variante B 3 Monate. Welche bevorzugen Sie?";
    if (hasObjection) return "Ok. Was genau hält Sie ab: Budget, Timing oder Sicherheit? Dann adressiere ich es gezielt.";
    if (talksValue) return "Dann lassen Sie uns Option A festhalten und Start am 01. des nächsten Monats anpeilen.";
    return "Ich schlage einen Pilot mit klaren KPIs vor. Stimmen Sie einem Starttermin in 2 Wochen zu?";
  }
  return "Verstehe. Wie gehen wir den nächsten Schritt?";
}

function clamp(v:number, a:number, b:number){ return Math.max(a, Math.min(b, v)); }

function scoreSession(session:any) {
  const transcript = session.messages || [];
  const agentMsgs = transcript.filter((m:any) => m.role === "agent");
  const aiMsgs = transcript.filter((m:any) => m.role === "ai");
  const textAll = agentMsgs.map((m:any) => (m.text||"").toLowerCase()).join(" ");
  const qCount = (textAll.match(/\?/g) || []).length;
  const discoveryHits = discoveryKeywords.filter((k) => textAll.includes(k)).length;
  const valueHits = valueKeywords.filter((k) => textAll.includes(k)).length;
  const objectionHits = objections.filter((k) => textAll.includes(k)).length;
  const closeHits = closingSignals.filter((k) => textAll.includes(k)).length;
  let talkRatio = agentMsgs.map((m:any)=>m.text||"").join(" ").length / Math.max(1,(agentMsgs.map((m:any)=>m.text||"").join(" ")+aiMsgs.map((m:any)=>m.text||"").join(" ")).length);
  talkRatio = clamp(talkRatio,0,1);
  const structure = clamp((discoveryHits >= 3 ? 0.35 : discoveryHits * 0.08) + (valueHits >= 2 ? 0.25 : valueHits * 0.1), 0, 0.6);
  const handling = clamp(0.2 - objectionHits * 0.03 + Math.min(closeHits * 0.05, 0.1), 0, 0.3);
  const balance = clamp(0.2 - Math.abs(0.55 - talkRatio), 0, 0.2);
  const questioning = clamp(Math.min(qCount * 0.02, 0.2), 0, 0.2);
  let raw = structure + handling + balance + questioning;
  raw = clamp(raw, 0.05, 0.95);
  const score = Math.round(raw * 100);
  const strengths:string[] = [];
  if (discoveryHits >= 3) strengths.push("gute Bedarfsermittlung");
  if (valueHits >= 2) strengths.push("Nutzenargumentation");
  if (questioning > 0.12) strengths.push("fragestark");
  if (balance > 0.12) strengths.push("gute Gesprächssteuerung");
  const improves:string[] = [];
  if (discoveryHits < 3) improves.push("mindestens 3 Discovery-Fragen stellen");
  if (valueHits < 2) improves.push("Nutzen klar mit KPI verknüpfen");
  if (objectionHits > 0) improves.push("Einwände präzise spiegeln und verengen");
  if (closeHits < 1) improves.push("klaren Next Step vereinbaren");
  const actions = [
    "Formuliere einen 15-Sekunden-Nutzenpitch",
    "Nutze SPIN: Situation, Problem, Impact, Need-Payoff",
    "Behandle den Top-Einwand mit Frage-Rahmen-Angebot",
    "Sichere ein konkretes Datum/Uhrzeit als Next Step",
  ];
  return { score, strengths, improves, actions };
}

export default function SimulatorPage(){
  const [scenario, setScenario] = useState("cold");
  const [agentName, setAgentName] = useState("");
  const [team, setTeam] = useState("");
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState("");
  const [running, setRunning] = useState(false);
  const [startAt, setStartAt] = useState<string|null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [score, setScore] = useState<any>(null);
  const timer = useRef<any>(null);

  useEffect(()=>{
    if(!running) return;
    timer.current = setInterval(()=>setElapsed(e=>e+1),1000);
    return ()=>clearInterval(timer.current);
  },[running]);

  const persona = SCENARIOS[scenario].persona;
  const hints = SCENARIOS[scenario].hints;

  const startSim = ()=>{
    setMessages([{ id: crypto.randomUUID(), role: "ai", text: (aiReply as any)({ scenario, userMsg: "", turns: [] }), ts: new Date().toISOString() }]);
    setRunning(true);
    setStartAt(new Date().toISOString());
    setElapsed(0);
    setScore(null);
  };
  const stopSim = ()=>{
    setRunning(false);
    const session:any = { scenario, agentName: agentName || "Agent", team: team || "Team", startedAt: startAt, endedAt: new Date().toISOString(), durationSec: elapsed, messages };
    const evalRes = scoreSession(session);
    (session as any).eval = evalRes;
    const key = "ai-call-coach-sessions";
    const list = JSON.parse(localStorage.getItem(key) || "[]");
    list.push(session);
    localStorage.setItem(key, JSON.stringify(list));
    setScore(evalRes);
  };
  const send = ()=>{
    if(!input.trim()) return;
    const userMsg:any = { id: crypto.randomUUID(), role: "agent", text: input.trim(), ts: new Date().toISOString() };
    const nextMsgs = [...messages, userMsg];
    const aiMsg:any = { id: crypto.randomUUID(), role: "ai", text: (aiReply as any)({ scenario, userMsg: userMsg.text, turns: nextMsgs }), ts: new Date().toISOString() };
    setMessages([...nextMsgs, aiMsg]);
    setInput("");
  };

  const sessions = (typeof window !== "undefined") ? JSON.parse(localStorage.getItem("ai-call-coach-sessions") || "[]") : [];

  return (
    <main className="min-h-screen p-6 md:p-10">
      <div className="max-w-6xl mx-auto">
        <header className="flex items-center gap-3 mb-6">
          <img src="/logo-light.svg" alt="AI Call Coach" width={36} height={36} />
          <h1 className="text-2xl font-bold">AI CALL COACH</h1>
        </header>

        <div className="grid md:grid-cols-3 gap-4">
          <div className="md:col-span-1 bg-white rounded-2xl shadow p-4">
            <h2 className="font-semibold mb-2">Setup</h2>
            <label className="block text-sm">Agent Name</label>
            <input value={agentName} onChange={e=>setAgentName(e.target.value)} className="w-full border rounded-lg p-2 mb-2" placeholder="z.B. Lisa" />
            <label className="block text-sm">Team</label>
            <input value={team} onChange={e=>setTeam(e.target.value)} className="w-full border rounded-lg p-2 mb-4" placeholder="z.B. Team Nord" />
            <label className="block text-sm">Szenario</label>
            <select value={scenario} onChange={e=>setScenario(e.target.value)} className="w-full border rounded-lg p-2 mb-4">
              {Object.values(SCENARIOS).map((s:any)=> (<option key={(s as any).id} value={(s as any).id}>{(s as any).title}</option>))}
            </select>

            <div className="text-sm bg-gray-50 border rounded-lg p-3 mb-4">
              <div className="font-medium">Persona</div>
              <div>{persona.name} - {persona.role}</div>
              <div>Haltung: {persona.attitude}</div>
              <div>Ziele: {persona.goals}</div>
            </div>

            <div className="text-sm bg-gray-50 border rounded-lg p-3">
              <div className="font-medium mb-1">Hinweise</div>
              <ul className="list-disc ml-4">
                {hints.map((h:string, i:number)=>(<li key={i}>{h}</li>))}
              </ul>
            </div>

            <div className="mt-4 flex gap-2">
              {!running ? (
                <button onClick={startSim} className="px-3 py-2 rounded-xl bg-green-600 text-white shadow">Start</button>
              ) : (
                <button onClick={stopSim} className="px-3 py-2 rounded-xl bg-red-600 text-white shadow">Stop & Auswerten</button>
              )}
            </div>
          </div>

          <div className="md:col-span-2 bg-white rounded-2xl shadow flex flex-col h-[70vh]">
            <div className="flex-1 overflow-auto p-4 space-y-3">
              {messages.map((m:any)=>(
                <div key={m.id} className={`max-w-[85%] ${m.role==='agent'?'ml-auto':''}`}>
                  <div className={`${m.role==='agent'?'bg-blue-600 text-white':'bg-gray-100'} rounded-2xl px-3 py-2`}> {m.text} </div>
                  <div className="text-[10px] text-gray-500 mt-1">{m.role==='agent'?(agentName||'Agent'):'KI Persona'}</div>
                </div>
              ))}
            </div>
            <div className="p-3 border-t flex gap-2">
              <input disabled={!running} value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{ if(e.key==='Enter') send(); }} className="flex-1 border rounded-xl p-2" placeholder={running?"Nachricht tippen und Enter":"Auf Start klicken"} />
              <button disabled={!running} onClick={send} className="px-3 py-2 rounded-xl bg-black text-white">Senden</button>
            </div>
          </div>
        </div>

        {score && (
          <div className="mt-6 grid md:grid-cols-3 gap-4">
            <div className="bg-white rounded-2xl shadow p-4">
              <h3 className="font-semibold mb-2">Gesamtscore</h3>
              <div className="text-3xl font-bold">{score.score}/100</div>
            </div>
            <div className="bg-white rounded-2xl shadow p-4">
              <h3 className="font-semibold mb-2">Stärken</h3>
              <ul className="list-disc ml-4 text-sm">
                {score.strengths.length? score.strengths.map((s:string,i:number)=>(<li key={i}>{s}</li>)) : (<li>noch keine</li>)}
              </ul>
            </div>
            <div className="bg-white rounded-2xl shadow p-4">
              <h3 className="font-semibold mb-2">Verbessern</h3>
              <ul className="list-disc ml-4 text-sm">
                {score.improves.map((s:string,i:number)=>(<li key={i}>{s}</li>))}
              </ul>
            </div>
            <div className="bg-white rounded-2xl shadow p-4 md:col-span-3">
              <h3 className="font-semibold mb-2">Konkrete Aufgaben</h3>
              <ol className="list-decimal ml-4 text-sm flex flex-wrap gap-4">
                {score.actions.map((a:string,i:number)=>(<li key={i}>{a}</li>))}
              </ol>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
