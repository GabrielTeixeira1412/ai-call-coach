import Link from "next/link";
import Image from "next/image";

export default function Page() {
  return (
    <main className="min-h-screen p-6 md:p-10">
      <header className="flex items-center gap-3 mb-8">
        <Image src="/logo-light.svg" alt="AI Call Coach" width={40} height={40} />
        <h1 className="text-2xl font-bold">AI CALL COACH</h1>
      </header>
      <section className="grid gap-6 md:grid-cols-2">
        <div className="bg-white p-6 rounded-2xl shadow">
          <h2 className="font-semibold mb-2">Simulator</h2>
          <p className="text-sm text-gray-600 mb-4">Kaltakquise, Bedarf, Abschluss. KI-Persona, Transkript, KPI.</p>
          <Link href="/simulator" className="inline-block bg-black text-white px-4 py-2 rounded-xl">Starten</Link>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow">
          <h2 className="font-semibold mb-2">Manager</h2>
          <p className="text-sm text-gray-600 mb-4">Scores, Stärken, Schwächen, CSV Export.</p>
          <Link href="/manager" className="inline-block bg-black text-white px-4 py-2 rounded-xl">Oeffnen</Link>
        </div>
      </section>
    </main>
  );
}
